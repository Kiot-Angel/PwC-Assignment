const express = require('express')
const cors = require('cors')
var fs = require('fs')
// var chalk = require('chalk');
const userService = require('./Validators/Validators')


const app = express();
app.use(express.json())
app.use(cors())
const port = process.env.PORT || 3000


// SIGNIN API
app.post('/login', (req, res) => {
    const users = loadUser()

    userService.authenticate(req.body.email, req.body.password, users)
        .then(user => {
            addToken(user.token)
            return res.status(201).send(user)
        })
        .catch(error => {
            console.log('error', error)
            return res.status(401).send(error)
        })

})

// FORGOT PASSWORD API
app.post('/passwordReset', (req, res) => {
    
    const users = loadUser();
    const registeredUser = users.find((user) => user.email === req.body.email)
    if (registeredUser) {
        registeredUser.password = req.body.password
        const filteredPeople = users.filter((item) => item.email !== req.body.email);
        filteredPeople.push(registeredUser)
        saveUser(filteredPeople)
        return res.status(201).send("Successfully Update")
    } else {
        return res.status(401).send("Error Fetching Data")
    }

})

// SIGNUP API
app.post('/register', (req, res) => {
    console.log('I got from api', req.body)
    const users = loadUser()
    const duplicateUser = users.find((user) => user.email === req.body.email)

    if (duplicateUser) {
        console.log('Already Registered')
        res.status(401).send({ error: "user Already Registered" })
    } else {
        // console.log('Need to Register')
        users.push(req.body)
        saveUser(users)
        res.status(201).send(req.body)
    }

})

app.post('/logout', async (req, res) => {
    try {
    removeToken(req.body.token)
    return  res.status(201).send('Logout Successfull')
    } catch (error) {
     return   res.status(401).send('Unable to Logout')
    }
    
})

    app.post('/emailValid', (req, res) => {
        try {
            var users = loadUser()
            let emails = users.find((email) => email.email == req.body.email)
            if(emails){
                return  res.status(500).send('Email Error')
            }
            else{
                return  res.status(201).send('Email Success Successfull')
            }
        } catch (error) {
            console.log('error')
            return  res.status(401).send('Email Error')
        }
    })

const loadUser = () => {
    try {
        const dataBuffer = fs.readFileSync('./user.json');
        const dataJson = dataBuffer.toString();
        //  console.log('JSON Data --> ',dataJson)
        return JSON.parse(dataJson)
    } catch (error) {
        return []
    }
}

const saveUser = (note) => {
    const dataJSON = JSON.stringify(note);
    fs.writeFileSync('./user.json', dataJSON);
}

const addToken = (token) => {
    const dataBuffer = fs.readFileSync('./tokenlist.json');
    const dataJson = dataBuffer.toString();
    var mytoken = JSON.parse(dataJson)
    mytoken.push({ token: token })
    const dataJSON = JSON.stringify(mytoken);
    fs.writeFileSync('./tokenlist.json', dataJSON);
}

const removeToken = (removeToken) => {
    const dataBuffer = fs.readFileSync('./tokenlist.json');
    const dataJson = dataBuffer.toString();
    var mytoken = JSON.parse(dataJson)
    mytoken = mytoken.filter((token) => {
        return token.token !== removeToken
    })

    const dataJSON = JSON.stringify(mytoken);
    fs.writeFileSync('./tokenlist.json', dataJSON);
}


app.listen(port, () => {
    console.log('Server Started on port ' + port)
})