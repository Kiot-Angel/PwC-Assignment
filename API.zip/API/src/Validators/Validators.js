var fs = require('fs')
const express = require('express')
const cors = require('cors')
const jwt = require('jsonwebtoken')
const config = require("../config/config.json")

async function authenticate(email, password, users) {

    const registeredUser = users.find((user) => user.email === email && user.password === password)

    if (!registeredUser) {
        var error = {
            message: 'Login or Password dont match'
        }
        console.log('Username or password is incorrect')
        throw 'Username or password is incorrect';

    } else {
        const token = jwt.sign({ email: registeredUser.email.toString() }, config.secret, { expiresIn: '7d' });
        console.log('Login Successful')
        return {
            ...omitPassword(registeredUser),
            token
        }

    }

}


function omitPassword(user) {
    const { password, ...userWithoutPassword } = user;
    return userWithoutPassword;
}

module.exports = {
    authenticate
}