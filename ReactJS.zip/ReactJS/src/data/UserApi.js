import axios from 'axios'
// import { BehaviorSubject } from 'rxjs';


export default class UserApi{

    static userLogin(email,password){
      return  axios.post("http://localhost:3000/login", {email, password}, {
            headers: {
                'Content-Type': 'application/json',
            }
        })
        // .then(res => {
        //     console.log('Success',res.data)
        //     localStorage.setItem('user', JSON.stringify(res.data));
        //     return res.data
        // })
        // .catch(error => {
        //     console.log('UnAuthorized',error)
        //     return  new Error('Username or password is incorrect')
        // })
        
        
    }

    static userRegister(userdetails){
        return axios.post("http://localhost:3000/register", userdetails, {
            headers: {
                'Content-Type': 'application/json',
            }
        })
        .then((res) => {
            console.log(res.data)
            return res.data
        })
        .catch(error => console.log(error))
    }

    static passwordReset(email, password){
        console.log(email, password)
        return axios.post("http://localhost:3000/passwordReset", {email, password}, {
            headers: {
                'Content-Type': 'application/json',
            }
    })
}
    static userLogout(user){
        console.log('User is', user)
        return axios.post("http://localhost:3000/logout", user, {
            headers: {
                'Content-Type': 'application/json',
            }
    })
    }

    static emailValidation(email){
        return axios.post("http://localhost:3000/emailValid", { email }, {
            headers: {
                'Content-Type': 'application/json',
            }
    })
    }
}