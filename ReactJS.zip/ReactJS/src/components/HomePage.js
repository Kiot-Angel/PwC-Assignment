import React from 'react';
import { Link } from 'react-router-dom';
import UserApi from '../data/UserApi';
// import { connect } from 'react-redux';

// import { userActions } from '../_actions';

class HomePage extends React.Component {
    // componentDidMount() {
    //     this.props.getUsers();
    // }

    handleLogout(id) {
        var user = JSON.parse(localStorage.getItem('user'))
        UserApi.userLogout(user)
            .then(res => {
                console.log('Logout done', res)
                localStorage.removeItem('user')
            })
            .catch(error => console.log('Error while logout', error))
        return (e) => this.props.deleteUser(id);
    }

    render() {
        const user = JSON.parse(localStorage.getItem('user'));
        console.log('Data is', JSON.parse(localStorage.getItem('user')))
        return (
            <>
                <div>
                    <nav className="navbar navbar-dark bg-primary ">
                        <a className="navbar-brand text-white" style={{ color: "white" }}>Welcome <b>{user.CustomerName}</b></a>
                        <div className="my-2 my-lg-0 mr-sm-2 justify-content-center">
                            <Link to="/login" style={{ float: "right", color: "white" }} className="navbar-brand" onClick={this.handleLogout}>
                                <i className="fa fa-sign-out" aria-hidden="true" style={{ color: "white" }} title="Click to Logout"></i>
                                Logout </Link>
                        </div>
                    </nav>
                    <div className="container-fluid">
                        <h1 style={{ textAlign: "center", fontFamily: "Arial, sans-serif" }}>Hi {user.CustomerName}!</h1>
                        <h3>Your Details:</h3>
                        <table className="table table-bordered" style={{ backgroundColor: 'white', height: "100%" }}>
                            <thead>
                                <tr>
                                    <th>
                                        Customer Name
                                    </th>
                                    <th>
                                        Email
                                    </th>
                                    <th>
                                        Phone Number
                                    </th>
                                    <th>
                                        Address
                                    </th>
                                    <th>
                                        City
                                    </th>
                                    <th>
                                        State
                                    </th>
                                    <th>
                                        Country
                                    </th>
                                    <th>
                                        Zip Code
                                    </th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>{user.CustomerName}</td>
                                    <td>{user.email}</td>
                                    <td>{user.phone}</td>
                                    <td>{user.Address}</td>
                                    <td>{user.city}</td>
                                    <td>{user.state}</td>
                                    <td>{user.country}</td>
                                    <td>{user.zipCode}</td>
                                </tr>
                            </tbody>
                        </table>

                        <p>

                        </p>
                    </div>

                </div>
            </>
        );
    }
}

export default HomePage

// function mapState(state) {
//     const { users, authentication } = state;
//     const { user } = authentication;
//     return { user, users };
// }

// const actionCreators = {
//     getUsers: userActions.getAll,
//     deleteUser: userActions.delete
// }

// const connectedHomePage = connect(mapState, actionCreators)(HomePage);
// export { connectedHomePage as HomePage };