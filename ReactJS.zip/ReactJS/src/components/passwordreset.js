
import React from 'react'
import UserApi from '../data/UserApi';
import { Redirect } from 'react-router-dom';
import { Link } from 'react-router-dom';

class PasswordReset extends React.Component {
    constructor(props) {
        super(props);

        // reset login status
        //  this.props.logout();

        this.state = {
            email: '',
            password: '',
            confirmPassword:'',
            submitted: false,
            toLogin: false,
            alertMessage: false,
            confirmPasswordDontMatch:false
        };

        this.handleChange = this.handleChange.bind(this);
        this.handleSubmit = this.handleSubmit.bind(this);
    }

    handleChange(e) {
        const { name, value } = e.target;
        this.setState({ [name]: value });
      
    }

   async handleSubmit(e) {
        e.preventDefault();

        this.setState({ submitted: true });

        const { email, password, confirmPassword } = this.state;
        if(this.state.password !== confirmPassword){
            this.setState({
                confirmPasswordDontMatch: true
            })
            return
        }
        
        if (email && password && confirmPassword) {
            console.log(email, password)
            UserApi.passwordReset(email, password, confirmPassword)
                .then(res => {
                    console.log('Password Reset Page', res)
                    if (res.status === 201) {
                        this.setState({
                            toLogin: true
                        });
                   }
                })
                .catch(error => {
                    console.log('Login Error', JSON.parse(JSON.stringify(error)))
                    this.setState({
                        alertMessage: true
                    })
                })
        }
    }

    render() {
        const { loggingIn } = this.props;
        const { email, password, submitted, confirmPassword } = this.state;
        if (this.state.toLogin) {
          
            return (<Redirect to="/login" />)
        }
        
        return (
            <>
            <div style={{background: "white"}}>
            <div className="col-md-6 col-md-offset-3" style={{ paddingTop: "20px" }}>
                    {this.state.alertMessage &&
                        <div className={`alert alert-danger`}>
                            Oops! Credentials dont Match</div>
                    }
                </div>
                <div className="col-md-6 col-md-offset-3">
                    <h2 style={{ textAlign: "center",fontFamily:"Arial, sans-serif" }}><b>Password Reset</b></h2>
                    <form name="form" onSubmit={this.handleSubmit}>
                        <div className={'form-group' + (submitted && !email ? ' has-error' : '')}>
                            <label htmlFor="email">Email</label>
                            <input type="email" className="form-control" name="email" value={email} onChange={this.handleChange} placeholder="mail@website.com" />
                            {submitted && !email &&
                                <div className="help-block">email is required</div>
                            }
                        </div>
                        <div className={'form-group' + (submitted && !password ? ' has-error' : '')}>
                            <label htmlFor="password">Password</label>
                            <input type="password" className="form-control" name="password" value={password} onChange={this.handleChange} placeholder="Enter Password" />
                            {submitted && !password &&
                                <div className="help-block">Password is required</div>
                            }
                        </div>

                        <div className={'form-group' + (submitted && !confirmPassword ? ' has-error' : '')}>
                            <label htmlFor="confirmPassword">Confirm Password</label>
                            <input type="password" className="form-control" name="confirmPassword" value={confirmPassword} onChange={this.handleChange} placeholder="Confirm Password"/>
                            {submitted && !confirmPassword &&
                                <div className="help-block">Confirm Password is required</div>
                            }
                            {
                                this.state.confirmPasswordDontMatch &&  <div className="help-block">Password and Confirm Password dont Match</div>
                            }
                        </div>
                        <div className="form-group">
                            <button className="btn btn-primary">Submit</button>
                            {loggingIn &&
                                <img src="data:image/gif;base64,R0lGODlhEAAQAPIAAP///wAAAMLCwkJCQgAAAGJiYoKCgpKSkiH/C05FVFNDQVBFMi4wAwEAAAAh/hpDcmVhdGVkIHdpdGggYWpheGxvYWQuaW5mbwAh+QQJCgAAACwAAAAAEAAQAAADMwi63P4wyklrE2MIOggZnAdOmGYJRbExwroUmcG2LmDEwnHQLVsYOd2mBzkYDAdKa+dIAAAh+QQJCgAAACwAAAAAEAAQAAADNAi63P5OjCEgG4QMu7DmikRxQlFUYDEZIGBMRVsaqHwctXXf7WEYB4Ag1xjihkMZsiUkKhIAIfkECQoAAAAsAAAAABAAEAAAAzYIujIjK8pByJDMlFYvBoVjHA70GU7xSUJhmKtwHPAKzLO9HMaoKwJZ7Rf8AYPDDzKpZBqfvwQAIfkECQoAAAAsAAAAABAAEAAAAzMIumIlK8oyhpHsnFZfhYumCYUhDAQxRIdhHBGqRoKw0R8DYlJd8z0fMDgsGo/IpHI5TAAAIfkECQoAAAAsAAAAABAAEAAAAzIIunInK0rnZBTwGPNMgQwmdsNgXGJUlIWEuR5oWUIpz8pAEAMe6TwfwyYsGo/IpFKSAAAh+QQJCgAAACwAAAAAEAAQAAADMwi6IMKQORfjdOe82p4wGccc4CEuQradylesojEMBgsUc2G7sDX3lQGBMLAJibufbSlKAAAh+QQJCgAAACwAAAAAEAAQAAADMgi63P7wCRHZnFVdmgHu2nFwlWCI3WGc3TSWhUFGxTAUkGCbtgENBMJAEJsxgMLWzpEAACH5BAkKAAAALAAAAAAQABAAAAMyCLrc/jDKSatlQtScKdceCAjDII7HcQ4EMTCpyrCuUBjCYRgHVtqlAiB1YhiCnlsRkAAAOwAAAAAAAAAAAA==" alt="Loading" />
                            }
                            &nbsp;
                            <Link to="/login" className="btn btn-info">Back</Link>
                        </div>
                    </form>
                  
                </div>
            
            </div>
            </>
        )
    }

}

// const actionCreators = {
//     login: userActions.login,
//     logout: userActions.logout
// };

// const connectedLoginPage = connect(mapState, actionCreators)(LoginPage);
// export { connectedLoginPage as LoginPage };
export default PasswordReset