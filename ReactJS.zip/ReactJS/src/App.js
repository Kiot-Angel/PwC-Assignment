import { BrowserRouter as Router, Route, Switch, Redirect } from 'react-router-dom';
import  PrivateRoute  from './components/PrivateRoute';
import  HomePage  from './components/HomePage';
import  LoginPage  from './components/LoginPage';
import RegisterPage from './components/RegisterPage';
import Passwordreset from './components/passwordreset';
import './App.css';

function App() {
  return (
    <div>
            <Router>
                <Switch>
                    <PrivateRoute exact path="/" component={HomePage} />
                    <Route path="/login" component={LoginPage} />
                    <Route path="/register" component={RegisterPage} />
                    <Route path="/passwordreset" component={Passwordreset} />
                    <Redirect from="*" to="/" />
                </Switch>
            </Router>
        </div>
  );
}

export default App;
